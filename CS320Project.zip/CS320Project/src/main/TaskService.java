package main;

import java.util.ArrayList;
import java.util.List;

public class TaskService {

	private List<Task> tasks;

    // Constructor
    public TaskService() {
        tasks = new ArrayList<>();
    }

    // Add a new task with unique ID
    public void addTask(Task task) {
        if (searchByTaskID(task.getTaskID()) != null) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        tasks.add(task);
    }
    

    // Delete a task by ID
    public void deleteTask(String taskID) {
        Task task = searchByTaskID(taskID);
        if (task != null) {
            tasks.remove(task);
        } else {
            throw new IllegalArgumentException("Task not found");
        }
    }

    // Update task name
    public void updateName(String taskID, String name) {
        Task task = searchByTaskID(taskID);
        if (task != null) {
            task.setName(name);
        } else {
            throw new IllegalArgumentException("Task not found");
        }
    }

    // Update task description
    public void updateDescription(String taskID, String description) {
        Task task = searchByTaskID(taskID);
        if (task != null) {
            task.setDescription(description);
        } else {
            throw new IllegalArgumentException("Task not found");
        }
    }

    // Find a task by ID
    private Task searchByTaskID(String taskID) {
        for (Task task : tasks) {
            if (task.getTaskID().equals(taskID)) {
                return task;
            }
        }
        return null;
    }

    // Getter method
    public List<Task> getTasks() {
        return tasks;
    }
}
