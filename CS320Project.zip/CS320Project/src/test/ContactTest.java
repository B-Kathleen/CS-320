package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;

import main.Contact;

import org.junit.jupiter.api.Test;

class ContactTest {

	// Basic contact creation
	@Test
	void testContactClass() {
		Contact contact = new Contact("123","Brenna", "Freilich", "1234567890", "123 Main St");
		assertTrue(contact.getContactID().equals("123"));
		assertTrue(contact.getFirstName().equals("Brenna"));
		assertTrue(contact.getLastName().equals("Freilich"));
		assertTrue(contact.getPhoneNumber().equals("1234567890"));
		assertTrue(contact.getAddress().equals("123 Main St"));
	}
	
	@Test
	void testContactClassIDNull() {
	Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact(null,"Brenna", "Freilich", "1234567890", "123 Main St");
	}); }
	
	 // ID too long
    @Test
    void testContactClassIDTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901","Brenna", "Freilich", "1234567890", "123 Main St");
        });
    }

    // firstName null
    @Test
    void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", null, "Freilich", "1234567890", "123 Main St");
        });
    }

    // firstName too long
    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "ThisNameIsWayTooLong", "Freilich", "1234567890", "123 Main St");
        });
    }

    // lastName null
    @Test
    void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Brenna", null, "1234567890", "123 Main St");
        });
    }

    // lastName too long
    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Brenna", "ThisLastNameIsTooLong", "1234567890", "123 Main St");
        });
    }

    // phoneNumber null
    @Test
    void testPhoneNumberNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Brenna", "Freilich", null, "123 Main St");
        });
    }

    // phoneNumber too short
    @Test
    void testPhoneNumberTooShort() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Brenna", "Freilich", "12345", "123 Main St");
        });
    }

    // phoneNumber too long
    @Test
    void testPhoneNumberTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Brenna", "Freilich", "1234567890123", "123 Main St");
        });
    }

    // address null
    @Test
    void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Brenna", "Freilich", "1234567890", null);
        });
    }

    // address too long
    @Test
    void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "Brenna", "Freilich", "1234567890", "This address is definitely way too long for the requirement");
        });
    }


}
