package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import main.Task;
import main.TaskService;

class TaskServiceTest {

    // Method to create tasks
    private Task createTask(String id, String name, String description) {
        return new Task(id, name, description);
    }

    // Add task
    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        Task task = createTask("001", "Homework", "Complete CS assignment");
        service.addTask(task);

        assertEquals(1, service.getTasks().size());
        assertEquals("Homework", service.getTasks().get(0).getName());
    }

    // Add task with duplicate ID
    @Test
    void testAddDuplicateTaskID() {
        TaskService service = new TaskService();
        Task task1 = createTask("001", "Homework", "Complete CS assignment");
        Task task2 = createTask("001", "Project", "Complete Java project");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
    }

    // Delete task
    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = createTask("001", "Homework", "Complete CS assignment");
        service.addTask(task);

        service.deleteTask("001");

        assertEquals(0, service.getTasks().size());
    }

    // Delete nonexistent task
    @Test
    void testDeleteNonExistentTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
    }

    // Update fields
    @Test
    void testUpdateTaskFields() {
        TaskService service = new TaskService();
        Task task = createTask("001", "Homework", "Complete CS assignment");
        service.addTask(task);

        service.updateName("001", "Project");
        service.updateDescription("001", "Complete Java project");

        assertEquals("Project", service.getTasks().get(0).getName());
        assertEquals("Complete Java project", service.getTasks().get(0).getDescription());
    }

    // Update nonexistent tasks
    @Test
    void testUpdateNonExistentTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> service.updateName("999", "NoName"));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("999", "No description"));
    }

   
}
