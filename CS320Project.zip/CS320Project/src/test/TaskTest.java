package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import main.Task;

class TaskTest {

	// Basic task test
    @Test
    void testTaskClass() {
        Task task = new Task("001", "Homework", "Complete CS assignment");
        assertEquals("001", task.getTaskID());
        assertEquals("Homework", task.getName());
        assertEquals("Complete CS assignment", task.getDescription());
    }

    // Null ID
    @Test
    void testTaskIDNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Complete CS assignment");
        });
    }

    // ID too long
    @Test
    void testTaskIDTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework", "Complete CS assignment"); // 11 chars
        });
    }

    // Name null
    @Test
    void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", null, "Complete CS assignment");
        });
    }

    // Name too long
    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", "SuperLongNameForJUnitTesting", "Complete CS assignment");
        });
    }

    // Null description
    @Test
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", "Homework", null);
        });
    }

    // Description too long
    @Test
    void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", "Homework", "This description is way too long to be valid for the assignment requirements");
        });
    }

    // Check updated fields
    @Test
    void testSettersUpdateFields() {
        Task task = new Task("001", "Homework", "Complete CS assignment");
        task.setName("Project");
        task.setDescription("Complete project");
        assertEquals("Project", task.getName());
        assertEquals("Complete project", task.getDescription());
    }

    // Setting an invalid name or description
    @Test
    void testSettersInvalid() {
        Task task = new Task("001", "Homework", "Complete CS assignment");

        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName("ThisNameIsWayTooLongforJUnitTesting"));

        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("This description is way too long to be valid for the assignment requirements"));
    }
}
