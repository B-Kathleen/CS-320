package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import main.Contact;

class ContactServiceTest {

    // Method to create a new contact
    private Contact createContact(String id, String firstName, String lastName, String phone, String address) {
        return new Contact(id, firstName, lastName, phone, address);
    }

    // Add contact
    @Test
    void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = createContact("123","Brenna","Freilich","1234567890","123 Main St");
        service.addContact(contact);

        assertEquals(1, service.getContacts().size());
        assertEquals("Brenna", service.getContacts().get(0).getFirstName());
    }

    // Duplicate ID
    @Test
    void testAddDuplicateContact() {
        ContactService service = new ContactService();
        Contact contact1 = createContact("123","Brenna","Freilich","1234567890","123 Main St");
        Contact contact2 = createContact("123","Alice","Smith","0987654321","456 Elm St");
        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    // Delete contact
    @Test
    void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = createContact("123","Brenna","Freilich","1234567890","123 Main St");
        service.addContact(contact);

        service.deleteContact("123");
        assertEquals(0, service.getContacts().size());
    }

    //Delete contact with no ID
    @Test
    void testDeleteNonExistentContact() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }

    // Update first name
    @Test
    void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = createContact("123","Brenna","Freilich","1234567890","123 Main St");
        service.addContact(contact);

        service.updateFirstName("123", "Alice");
        assertEquals("Alice", service.getContacts().get(0).getFirstName());
    }

    // Update last name
    @Test
    void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = createContact("123","Brenna","Freilich","1234567890","123 Main St");
        service.addContact(contact);

        service.updateLastName("123", "Smith");
        assertEquals("Smith", service.getContacts().get(0).getLastName());
    }

    // Update phone number
    @Test
    void testUpdatePhoneNumber() {
        ContactService service = new ContactService();
        Contact contact = createContact("123","Brenna","Freilich","1234567890","123 Main St");
        service.addContact(contact);

        service.updatePhoneNumber("123", "0987654321");
        assertEquals("0987654321", service.getContacts().get(0).getPhoneNumber());
    }

    // Update address
    @Test
    void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = createContact("123","Brenna","Freilich","1234567890","123 Main St");
        service.addContact(contact);

        service.updateAddress("123", "456 Elm St");
        assertEquals("456 Elm St", service.getContacts().get(0).getAddress());
    }

    
    // Update a nonexistent contact
    @Test
    void testUpdateNonExistentContact() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("999", "NoName"));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("999", "NoName"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhoneNumber("999", "0000000000"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("999", "No Address"));
    }
}
