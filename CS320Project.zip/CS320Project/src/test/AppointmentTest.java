package test;


import main.Appointment;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Checkup");
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Checkup", appointment.getDescription());
    }

    @Test
    void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Checkup");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Checkup");
        });
    }

    @Test
    void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Checkup");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", null, "Checkup");
        });
    }

    @Test
    void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, "This description is way too long and exceeds fifty characters!");
        });
    }
    
    @Test
    void testUpdateAppointmentFields() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("123", futureDate, "Checkup");

        // Update to new valid date
        Date newFutureDate = new Date(System.currentTimeMillis() + 200000);
        appointment.setAppointmentDate(newFutureDate);
        assertEquals(newFutureDate, appointment.getAppointmentDate());

        // Update to valid description
        appointment.setDescription("Updated description");
        assertEquals("Updated description", appointment.getDescription());
    }

}
