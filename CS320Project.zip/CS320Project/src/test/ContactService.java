package test;


import java.util.ArrayList;
import java.util.List;

import main.Contact;

public class ContactService {
	private List<Contact> contacts;

    public ContactService() {
        contacts = new ArrayList<>();
    }
    
    // Add a new contact with unique ID
    public void addContact(Contact contact) {
        if (searchByContactID(contact.getContactID()) != null) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.add(contact);
    }

    // Delete a contact by ID
    public void deleteContact(String contactId) {
        Contact contact = searchByContactID(contactId);
        if (contact != null) {
            contacts.remove(contact);
        } 
        else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

    // Update first name
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = searchByContactID(contactId);
        if (contact != null) {
            contact.setFirstName(firstName);
        } else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

    // Update last name
    public void updateLastName(String contactId, String lastName) {
        Contact contact = searchByContactID(contactId);
        if (contact != null) {
            contact.setLastName(lastName);
        } 
        else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

    // Update phone number
    public void updatePhoneNumber(String contactId, String phoneNumber) {
        Contact contact = searchByContactID(contactId);
        if (contact != null) {
            contact.setPhoneNumber(phoneNumber);
        } 
        else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

    // Update address
    public void updateAddress(String contactId, String address) {
        Contact contact = searchByContactID(contactId);
        if (contact != null) {
            contact.setAddress(address);
        } 
        else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

 // Search for a contact by ID
    private Contact searchByContactID(String contactId) {
        for (Contact contact : contacts) {
            if (contact.getContactID().equals(contactId)) {
                return contact;
            }
        }
        
        return null;
    }
    
    public List<Contact> getContacts() {
        return contacts;
    }
    
}
